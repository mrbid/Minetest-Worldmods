return {
	["boats:boat"] = {name = "boats:boat", drawtype = "entity"},
	["carts:cart"] = {name = "carts:cart", drawtype = "entity", frames = "0,0"},
	["default:chest"] = {name = "default:chest_open"},
	["default:chest_locked"] = {name = "default:chest_locked_open"},
	["doors:door_wood"] = {name = "doors:door_wood_a"},
	["doors:door_glass"] = {name = "doors:door_glass_a"},
	["doors:door_obsidian_glass"] = {name = "doors:door_obsidian_glass_a"},
	["doors:door_steel"] = {name = "doors:door_steel_a"},
	["xpanes:door_steel_bar"] = {name = "xpanes:door_steel_bar_a"},
}
